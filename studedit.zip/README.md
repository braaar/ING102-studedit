# ING102-studedit

Dette er github-repositoriet for prosjektgruppe D.E.S.P.A.C.I.T.O. 2 som jobber
med prosjektet studedit.

Medlemmer av gruppen:

- Hollie Lee Buchanan III h181395
- Brage Sekse Aarset h579704
- Sondre Melhus
- Christopher Nguyen
- Peter L. Liessem
